from django.db import models

# Create your models here.





class rwa(models.Model):
    Fins = models.CharField(max_length=100, verbose_name='fin_id')
    credit_risk = models.FloatField(verbose_name='Credit Risk, в %')
    market_risk = models.FloatField(verbose_name='Market Risk, в %')
    oper_risk = models.FloatField(verbose_name='Oper. Risk, в %')
    irrbb = models.FloatField(verbose_name='IRRBB, в %')
    overall = models.FloatField(verbose_name='Всего')
    credit_risk_120 = models.FloatField(verbose_name='Credit Risk, в % (от 120%)')
    market_risk_120 = models.FloatField(verbose_name='Market Risk, в % (от 120%)')
    oper_risk_120 = models.FloatField(verbose_name='Oper. Risk, в % (от 120%)')
    irrbb_120 = models.FloatField(verbose_name='IRRBB, в % (от 120%)')
    overall_120 = models.FloatField(verbose_name='Всего  (от 120%)')