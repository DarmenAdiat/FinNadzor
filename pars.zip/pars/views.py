from django.shortcuts import render, HttpResponse

# Create your views here.

from parser.main import *
from .models import rwa






def index(request):
    main(rwa)
    return HttpResponse('OK')