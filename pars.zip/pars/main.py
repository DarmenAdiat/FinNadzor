import requests
import pandas as pd
import os
import os
import django



def get_data():
    file_path = 'DATA.xlsx'
    df = pd.read_excel(file_path, header=1)
    for i in df.head():
        print(i)
    return df




def delete_fields(df):
    df.drop(columns=['Unnamed: 0','Credit Risk', 'Market Risk', 'Operational Risk', 'Наименование банков','N, п/п'], axis=1, inplace=True)
    df = df.drop(index=21)
    print(df)
    return df





def insert_data(df,model):
    verbose_name_to_field = {
    'fin_id': 'Fins',
    'Credit Risk, в %': 'credit_risk',
    'Market Risk, в %': 'market_risk',
    'Oper. Risk, в %': 'oper_risk',
    'IRRBB, в %': 'irrbb',
    'Всего': 'overall',
    'Credit Risk, в % (от 120%)': 'credit_risk_120',
    'Market Risk, в % (от 120%)': 'market_risk_120',
    'Oper. Risk, в % (от 120%)': 'oper_risk_120',
    'IRRBB, в % (от 120%)': 'irrbb_120',
    'Всего  (от 120%)': 'overall_120'
}
    for _, row in df.iterrows():
        data = {}
        for verbose_name, field in verbose_name_to_field.items():
            if pd.isnull(row[verbose_name]):
                print(f"Skipping row due to NULL value in {verbose_name}")
                break
            data[field] = row[verbose_name]
        else:  # This else corresponds to the for-loop, not the if statement
            model.objects.create(**data)



def main(model):
    df = get_data()
    delete_fields(df)
    insert_data(df,model)
    

if __name__ == "__main__":
    main()